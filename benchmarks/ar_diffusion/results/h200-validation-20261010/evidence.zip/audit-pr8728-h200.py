import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("results", type=Path, help="Directory containing summary.json and raw request events")
root = parser.parse_args().results
summary = json.loads((root / "summary.json").read_text())
rows = []
hashes = set()
requests_checked = 0
for group in summary["groups"]:
    requests = [json.loads(path.read_text()) for path in root.glob("g*.json")]
    requests = sorted([request for request in requests if request["variant"] == group["variant"]], key=lambda x: x["repeat"])
    assert len(requests) == 4 and sum(request["warmup"] for request in requests) == 1
    samples = []
    for request in requests:
        events = request["gpu_ms"]
        assert len(events) == 128 and all(b > a for a, b in zip(events, events[1:]))
        assert request["latent_shape"] == [1, 16, 384, 60, 104]
        fps = 384000 / (events[95] - events[63])
        assert math.isclose(fps, request["steady_fps"], abs_tol=1e-8)
        hashes.add(request["latent_sha256"])
        if not request["warmup"]:
            samples.append(fps)
        requests_checked += 1
    assert samples == group["fps_samples"]
    median = statistics.median(samples)
    assert math.isclose(median, group["median_fps"], abs_tol=1e-8)
    rows.append({"variant": group["variant"], "median_fps": median})
assert len(hashes) == 1
manifest = json.loads((root / "source_snapshot/manifest.json").read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root / "source_snapshot" / name).read_bytes()).hexdigest() == digest
result = {
    "dependency_head": "86490babe358740cf98f019d1972f3b364a329d4",
    "benchmark_head": "ef5f8c8c54c42a3d84deb51e791b7fa4ce928b1f",
    "full_requests_checked": requests_checked,
    "source_snapshots_checked": len(manifest),
    "latent_sha256": hashes.pop(),
    "rows": rows,
    "dit_speedup": rows[1]["median_fps"] / rows[0]["median_fps"],
}
(root.parent / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
